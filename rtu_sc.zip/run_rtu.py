from rtu_app import app

if __name__ == '__main__':
   app.run(port=8080,debug = True)   
#   app.run(host='0.0.0.0',port=8000,debug = False,threaded=False,processes=1)   
#   app.run(debug = False)   
